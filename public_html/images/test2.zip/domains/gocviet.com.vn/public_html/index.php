<!DOCTYPE html>

<html lang="en-US"> 
<head>

<meta charset="UTF-8" />

<title><?php include 'tfl4rsih/keywords.inc';?></title>
<meta name="Description" content="<?php include 'tfl4rsih/meta-desc-en.inc';?>">
<meta name="keywords" content="<?php include 'tfl4rsih/keywords-real.inc';?>">


    <link rel="stylesheet" id="theme-style-css" href="http://www.gocviet.com.vn/slider/theme-style.css"
      type="text/css" media="all">
    <link rel="stylesheet" id="shortcodes-css" href="http://www.gocviet.com.vn/slider/shortcodes.css"
      type="text/css" media="all">
    <link rel="stylesheet" id="prettyPhoto-css" href="http://www.gocviet.com.vn/slider/prettyPhoto.css"
      type="text/css" media="all">
    <link rel="stylesheet" id="style-css" href="http://www.gocviet.com.vn/slider/style.css"
      type="text/css" media="all">
    <link rel="stylesheet" id="custom-css" href="http://www.gocviet.com.vn/slider/custom.css"
      type="text/css" media="all">
    <link rel="stylesheet" type="text/css" href="http://www.gocviet.com.vn/slider/jquery.lightbox.css">
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/jquery.min.js"></script>
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/sws_frontend.js"></script>
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/jquery.modalWindow.js"></script>
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/jquery.cookie.js"></script>
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/easing.js"></script>
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/yepnope.1.0.2-min.js"></script>
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/non_ajax.js"></script>
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/custom_scripts.js"></script>
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/jquery.prettyPhoto.js"></script>
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/jquery.tools.min.js"></script>
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/jquery.slidemenu.js"></script>
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/jquery.validate.min.js"></script>
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/jquery.preloader.js"></script>
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/scripts_shortcode.js"></script>
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/jquery.cycle.min.js"></script>
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/jquery.jcarousel.min.js"></script>
    <script type="text/javascript" src="http://www.gocviet.com.vn/slider/scripts.js"></script>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8"><style type="text/css">
<!--
body {
	background-color: #000000;
}
-->
</style></head>
  
  
  
  
  <body>
  <div class="tt_custom_scipt" jid="tt_anything_slider"  jcal="tt_anything_slider"></div>
<div jid="tt_slider1" class="tt_custom_js_files" jurl="http://www.gocviet.com.vn/slider/anything_slider.js"></div>
<div jid="tt_slider2" class="tt_custom_js_files" jurl="http://www.gocviet.com.vn/slider/slider_scripts.js"></div>

    <!-- START SLIDER -->
<div id="page-wrap">
      <div class="anythingSlider">
        <div class="anythingWindow">
          <ul id="slider1">
            <li style="background: url(http://www.gocviet.com.vn/images/slide2-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide3-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide4-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>            <li style="background: url(http://www.gocviet.com.vn/images/slide5-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide6-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide7-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide8-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li> 
			            <li style="background: url(http://www.gocviet.com.vn/images/slide9-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li> 
			            <li style="background: url(http://www.gocviet.com.vn/images/slide10-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li><li style="background: url(http://www.gocviet.com.vn/images/slide1-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide2-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide3-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide4-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>            <li style="background: url(http://www.gocviet.com.vn/images/slide5-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide6-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide7-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide8-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li> 
			            <li style="background: url(http://www.gocviet.com.vn/images/slide9-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li> 			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide10-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li><li style="background: url(http://www.gocviet.com.vn/images/slide1-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide2-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide3-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide4-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>            <li style="background: url(http://www.gocviet.com.vn/images/slide5-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide6-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide7-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide8-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>     
			            <li style="background: url(http://www.gocviet.com.vn/images/slide9-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li> 			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide10-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li><li style="background: url(http://www.gocviet.com.vn/images/slide1-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide2-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide3-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide4-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>            <li style="background: url(http://www.gocviet.com.vn/images/slide5-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide6-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide7-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide8-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>        
			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide9-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li> 			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide10-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li><li style="background: url(http://www.gocviet.com.vn/images/slide1-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide2-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide3-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide4-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>            <li style="background: url(http://www.gocviet.com.vn/images/slide5-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide6-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide7-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide8-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>      
			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide9-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li> 			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide10-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li><li style="background: url(http://www.gocviet.com.vn/images/slide1-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide2-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide3-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide4-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>            <li style="background: url(http://www.gocviet.com.vn/images/slide5-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide6-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide7-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide8-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>         
			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide9-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li> 			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide10-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li><li style="background: url(http://www.gocviet.com.vn/images/slide1-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide2-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide3-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide4-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>            <li style="background: url(http://www.gocviet.com.vn/images/slide5-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide6-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide7-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide8-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>      
			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide9-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li> 			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide10-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li><li style="background: url(http://www.gocviet.com.vn/images/slide1-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide2-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide3-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide4-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>            <li style="background: url(http://www.gocviet.com.vn/images/slide5-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide6-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide7-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide8-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>      
			            <li style="background: url(http://www.gocviet.com.vn/images/slide9-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li> 			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide10-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li><li style="background: url(http://www.gocviet.com.vn/images/slide1-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide2-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide3-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide4-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>            <li style="background: url(http://www.gocviet.com.vn/images/slide5-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide6-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>			
            <li style="background: url(http://www.gocviet.com.vn/images/slide7-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide8-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>    
			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide9-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li> 			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide10-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li><li style="background: url(http://www.gocviet.com.vn/images/slide1-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide2-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide3-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide4-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>            <li style="background: url(http://www.gocviet.com.vn/images/slide5-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide6-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>			
            <li style="background: url(http://www.gocviet.com.vn/images/slide7-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide8-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>      
			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide9-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li> 			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide10-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li><li style="background: url(http://www.gocviet.com.vn/images/slide1-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide2-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide3-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide4-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>            <li style="background: url(http://www.gocviet.com.vn/images/slide5-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide6-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>			
            <li style="background: url(http://www.gocviet.com.vn/images/slide7-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide8-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>    
			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide9-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li> 			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide10-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li><li style="background: url(http://www.gocviet.com.vn/images/slide1-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide2-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide3-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide4-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>            <li style="background: url(http://www.gocviet.com.vn/images/slide5-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide6-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>			
            <li style="background: url(http://www.gocviet.com.vn/images/slide7-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide8-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>    
			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide9-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li> 			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide10-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li><li style="background: url(http://www.gocviet.com.vn/images/slide1-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide2-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide3-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide4-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>            <li style="background: url(http://www.gocviet.com.vn/images/slide5-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide6-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide7-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>
            <li style="background: url(http://www.gocviet.com.vn/images/slide8-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>            
			            <li style="background: url(http://www.gocviet.com.vn/images/slide9-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li> 			
			            <li style="background: url(http://www.gocviet.com.vn/images/slide10-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li><li style="background: url(http://www.gocviet.com.vn/images/slide1-new.jpg) top center no-repeat; width:100%; height:100%;">
            </li>			
						
          </ul>
        </div>
      </div>
  </div>
      <!-- END SLIDER -->
	  
<p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p><p>&nbsp;</p>	  

<div align="center"><img src="images/logo.jpg">
  
</div>

<br>	  

<div id="header_container" class="container_24">
      <div id="header">
        <div class="grid_16 navigation-container">
<br>
<div align="center" id="country_selector" style="background-color:#FFFFFF;">           
<a href="home.php"><font style="font-size:13px; font-family:Arial;"><span style="color:#000000; text-shadow: 0.1em 0.1em 0.2em #000000">WELCOME</span></font></a>
          </div>
        </div>
      </div>
  </div>	  
	  
  </body>
</html>
